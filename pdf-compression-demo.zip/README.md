# Synthetic PDF compression demonstration

Actual Refentra browser outputs observed 7 October 2026, independently checked.
No customer data. The photograph is AI-generated and was embedded from PNG.
One example does not guarantee a reduction, visual quality, or portal acceptance.

photo-text-vector.pdf: untouched original, 4,397,793 bytes.
compact-text-vector.pdf: already compact text/vector source, 1,990 bytes; lossless
returned No saving, so no smaller downloadable output was offered for that file.
actual-photo-lossless.pdf: actual output, 4,397,274 bytes, saving 519 bytes.
actual-photo-balanced.pdf: actual output, 336,783 bytes, JPEG 1536x1024.
actual-photo-strong.pdf: actual Smallest file output, 209,405 bytes, JPEG 1400x933.
All three photo outputs use the same original, not repeated lossy generations.
All text in both independent readers matches, page count/geometry matches,
and rendered pixels outside the photograph match at 144 dpi.
The lossless photograph bytes match source. Lossy photos do change: Balanced is
subtle here; Smallest file adds modest detail softening, not dramatic damage.

Bytes came from the actual offered browser Blob, not a tested physical OS save
dialog. The verifier did not recreate or compress outputs.
Try with the original at https://refentra.com/tools/compress-pdf/ and inspect
your copy. Already JPEG-compressed images can have very different outcomes.
manifest.json contains exact bytes and SHA-256 for each supplied file.
