import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const maxBodyBytes = 2 * 1024 * 1024;
const getRoutes = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ['/harness.js', ['harness.js', 'text/javascript; charset=utf-8']],
  ['/fixture.png', ['fixture.png', 'image/png']],
  ['/package/dist/browser-image-compression.js', ['package/dist/browser-image-compression.js', 'text/javascript; charset=utf-8']],
  ['/package/dist/browser-image-compression.js.map', ['package/dist/browser-image-compression.js.map', 'application/json']],
  ['/package/LICENSE', ['package/LICENSE', 'text/plain; charset=utf-8']],
  ['/results.json', ['results.json', 'application/json']],
  ['/independent-validation.json', ['independent-validation.json', 'application/json']],
  ['/REPORT.md', ['REPORT.md', 'text/plain; charset=utf-8']],
  ['/README.md', ['README.md', 'text/plain; charset=utf-8']],
]);
const postRoutes = new Map([
  ['/save/worker-output.bin', 'worker-output.bin'],
  ['/save/main-output.bin', 'main-output.bin'],
  ['/save/results.json', 'results.json'],
]);
const reply = (res, status, text) => {
  res.writeHead(status, { 'Content-Type': 'text/plain; charset=utf-8', 'X-Content-Type-Options': 'nosniff' });
  res.end(text);
};
const server = http.createServer((req, res) => {
  const port = server.address().port;
  const host = req.headers.host;
  if (host !== `127.0.0.1:${port}` && host !== `localhost:${port}`) {
    req.resume();
    reply(res, 403, 'Host not allowed');
    return;
  }
  let route;
  try {
    route = decodeURIComponent((req.url || '').split('?')[0]);
  } catch {
    req.resume();
    reply(res, 400, 'Malformed URL');
    return;
  }
  if (req.method === 'GET') {
    const entry = getRoutes.get(route);
    if (!entry) {
      reply(res, 404, 'Route not found');
      return;
    }
    fs.readFile(path.join(root, entry[0]), (error, data) => {
      if (error) {
        reply(res, error.code === 'ENOENT' ? 404 : 500, 'File unavailable');
        return;
      }
      res.writeHead(200, { 'Content-Type': entry[1], 'X-Content-Type-Options': 'nosniff' });
      res.end(data);
    });
    return;
  }
  if (req.method !== 'POST') {
    req.resume();
    reply(res, 405, 'Method not allowed');
    return;
  }
  const file = postRoutes.get(route);
  if (!file) {
    req.resume();
    reply(res, 404, 'Route not found');
    return;
  }
  if (req.headers.origin !== `http://${host}`) {
    req.resume();
    reply(res, 403, 'Same origin required');
    return;
  }
  const declaredLength = req.headers['content-length'];
  if (declaredLength !== undefined && (!/^\d+$/.test(declaredLength) || Number(declaredLength) > maxBodyBytes)) {
    req.resume();
    reply(res, 413, 'Body too large');
    return;
  }
  let size = 0;
  let rejected = false;
  const chunks = [];
  req.on('data', chunk => {
    if (rejected) return;
    size += chunk.length;
    if (size > maxBodyBytes) {
      rejected = true;
      chunks.length = 0;
      reply(res, 413, 'Body too large');
      return;
    }
    chunks.push(chunk);
  });
  req.on('error', () => {
    rejected = true;
    chunks.length = 0;
    if (!res.headersSent) reply(res, 400, 'Request failed');
  });
  req.on('aborted', () => {
    rejected = true;
    chunks.length = 0;
  });
  req.on('end', () => {
    if (rejected) return;
    fs.writeFile(path.join(root, file), Buffer.concat(chunks, size), error => {
      reply(res, error ? 500 : 200, error ? 'Write failed' : 'saved');
    });
  });
});
server.requestTimeout = 15_000;
server.headersTimeout = 10_000;
server.listen(0, '127.0.0.1', () => {
  fs.writeFileSync(path.join(root, 'server-port.txt'), String(server.address().port));
  console.log(server.address());
});
